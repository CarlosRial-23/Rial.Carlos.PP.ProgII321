package rialcarlosppprogii321;

public class TestJadinBotanico {

    public static void main(String[] args) {
        
        JardinBotanico jardinB = new JardinBotanico();
        cargarDatos(jardinB);
        jardinB.mostrarPlantas();
        try {
            jardinB.podarPlantas();
            
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
        
      /*
        Agregar plantas al sistema: 
o Se debe poder agregar un árbol llamado "Roble" en la zona norte del jardín, y al intentaragregar otra planta con el mismo nombre y ubicación, se debe lanzar una excepción. 
Mostrar plantas registradas: 
o El sistema debe listar todas las plantas, mostrando tanto los atributos comunes (nombrubicación, clima) como los específicos (altura máxima, densidad del follaje o temporada
de florecimiento). 
Poda de plantas: 
o El sistema debe permitir que los árboles y arbustos sean podados, mientras que debe
indicar que las flores no requieren poda. 
        */  

    }
    
    public static void cargarDatos(JardinBotanico jardin){
        Arbol arb1 = new Arbol("Roble", "Norte", "Templado", 10);
        Arbol arb2 = new Arbol("Eucalito", "Sur", "Templado", 9);
        Arbusto arbus1 = new Arbusto("Arbusto-A", "Sur", "Arido", 6);
        Arbusto arbus2 = new Arbusto("Arbusto-B", "Este", "Arido", 3);
        Flor flor1 = new Flor("Rosa", "Sur", "Calido", Temporada.VERANO);
        Flor flor2 = new Flor("Jazmin", "Sur", "Calido", Temporada.OTOÑO);
        Arbol arb3 = new Arbol("Roble", "Norte", "Templado", 12);
        try {
            jardin.agregarPlanta(arb1);
            jardin.agregarPlanta(arb2);
            jardin.agregarPlanta(arbus1);
            jardin.agregarPlanta(arbus2);
            jardin.agregarPlanta(flor1);
            jardin.agregarPlanta(flor2);
            jardin.agregarPlanta(arb3);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
        
    }
            

}
