package rialcarlosppprogii321;

public class PLantaRepetidaException extends RuntimeException{

    private static final String MESSAGE = "Esta planta ya se encuentra en nuestro jardir, plantada ahi";

    public PLantaRepetidaException() {
        super(MESSAGE);
    }
    
}
