package rialcarlosppprogii321;

public class Flor extends Planta{

    private Temporada temporada;

    public Flor (String nombre, String ubicacionJardin, String clima, Temporada temporada) {
        super(nombre, ubicacionJardin, clima);
        this.temporada = temporada;
    }

    @Override
    protected void PodarPlanta() {
        throw new FlorNoPuedenPodarException();
    }

    @Override
    public String toString() {
        return "Flor{" + super.toString() + " temporada=" + temporada + '}';
    }
    
    

    
    
    
}
