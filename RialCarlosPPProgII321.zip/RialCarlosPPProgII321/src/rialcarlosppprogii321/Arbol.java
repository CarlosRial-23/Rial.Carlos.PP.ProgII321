package rialcarlosppprogii321;

public class Arbol extends Planta{

    private int alturaMaxima;

    public Arbol(String nombre, String ubicacionJardin, String clima, int alturaMaxima) {
        super(nombre, ubicacionJardin, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    protected void PodarPlanta() {
        System.out.println( "Soy " + getTipo() + " y me estan Podando");
    }

    @Override
    public String toString() {
        return "Arbol{"+ super.toString() + " alturaMaxima=" + alturaMaxima + '}';
    }
    
    private String getTipo(){
        return "Arbol";
    }
    
    
    

}
