package rialcarlosppprogii321;

import java.util.Objects;

public abstract class Planta {

    private String nombre;
    private String ubicacionJardin;
    private String clima;

    public Planta(String nombre, String ubicacionJardin, String clima) {
        this.nombre = nombre;
        this.ubicacionJardin = ubicacionJardin;
        this.clima = clima;
    }
    
    protected abstract void PodarPlanta();
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        
        Planta other = (Planta) obj;
        return other.nombre.equals(nombre) && other.ubicacionJardin.equals(ubicacionJardin);
                
    }
    
    @Override
    public int hashCode(){
       return Objects.hash(nombre,ubicacionJardin);
    }

    @Override
    public String toString() {
        return  "nombre=" + nombre + ", ubicacionJardin=" + ubicacionJardin + ", clima=" + clima+",";
    }
    
    
    
    

}
