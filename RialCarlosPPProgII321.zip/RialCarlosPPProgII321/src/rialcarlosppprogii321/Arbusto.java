package rialcarlosppprogii321;

public class Arbusto extends Planta{

    private static final int MIN_DENSIDAD = 1;
    private static final int MAX_DENSIDAD = 10;
    private int densidad;

    public Arbusto(String nombre, String ubicacionJardin, String clima, int densidad){
        super(nombre, ubicacionJardin, clima);
        setDensidad(densidad);
    }

    public void setDensidad(int densidad) {
        if(densidad < MIN_DENSIDAD || densidad > MAX_DENSIDAD){
            throw new IllegalArgumentException("Cuotas invalidas");
        }
        this.densidad = densidad;
    }

    @Override
    protected void PodarPlanta() {
        System.out.println( "Soy " + getTipo() + " y me estan Podando");
    }

    @Override
    public String toString() {
        return "Arbusto{" + super.toString() + " densidad=" + densidad + '}';
    }
    
    private String getTipo(){
        return "Arbusto";
    }
    
    
    
    

}
