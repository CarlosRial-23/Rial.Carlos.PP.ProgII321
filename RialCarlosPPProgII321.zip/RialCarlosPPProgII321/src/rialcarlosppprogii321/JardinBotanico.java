package rialcarlosppprogii321;

import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {

    private List<Planta> plantas;

    public JardinBotanico() {
        plantas = new ArrayList<>();
    }
    /*
    • agregarPlanta(Planta planta): El botánico debe poder agregar cualquier tipo de planta al sistema. Se
    deberá lanzar una excepción personalizada si ya existe una planta con el mismo nombre y ubicación en el
    jardín. 
    */
    public void agregarPlanta(Planta p){
        
        if(p == null){
            throw new NullPointerException("Me pasate null en vez, de una planta");
        }
        if(plantas.contains(p)){
            throw new PLantaRepetidaException();
        }
        plantas.add(p);
        
    }
    
    public void podarPlantas(){
        for (Planta p: plantas){
            if(p instanceof Arbol a ){
                a.PodarPlanta();
            }
            if(p instanceof Arbusto a ){
                a.PodarPlanta();
            }
            if(p instanceof Flor f){
                f.PodarPlanta();
            }
        }
    }
    
    public void mostrarPlantas(){
        
        for (Planta p: plantas){
            System.out.println(p);
        }
        
    }
    
    
    
    

}
